tinyMCE.addI18n('ta.modxlink',{
    link_desc:"Insert/edit link"
});