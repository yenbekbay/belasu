tinyMCE.addI18n('cy.modxlink',{
    link_desc:"Insert/edit link"
});