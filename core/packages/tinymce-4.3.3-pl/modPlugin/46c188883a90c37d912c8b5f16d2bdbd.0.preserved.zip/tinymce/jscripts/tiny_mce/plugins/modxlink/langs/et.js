tinyMCE.addI18n('et.modxlink',{
    link_desc:"Insert/edit link"
});