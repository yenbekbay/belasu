tinyMCE.addI18n('ru.modxlink',{
    link_desc:"Insert/edit link"
});